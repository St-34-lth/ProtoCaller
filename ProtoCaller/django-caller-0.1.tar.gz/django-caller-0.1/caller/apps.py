from django.apps import AppConfig


class CallerConfig(AppConfig):
    name = 'caller'
