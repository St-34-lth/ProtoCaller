from django.contrib.auth.models import User, Group
from rest_framework import serializers
from .models import *
import json 

class CoverageSerializer(serializers.ModelSerializer):
    coverage = serializers.SerializerMethodField()
    def to_representation(self,instance):
        repr= super().to_representation(instance)
        try: 
            
            if self.context['coverage'] != None : 
                repr['id'] = instance.id
                repr['protein_id'] = instance.protein_id
                # repr['coverage'] = self.context['coverage']
            return repr
              
        except KeyError:
            # repr['organism_id'] = OrganismSerializer(instance.organism_id).data
            return Exception 
    def get_coverage(self,obj):
        return self.context['coverage']
        
    class Meta:
        model = Protein    
        fields = ['protein_id','id','coverage']

#not my code 
class DynamicFieldsModelSerializer(serializers.ModelSerializer):
    def __init__(self,*args,**kwargs):
        fields = kwargs.pop('fields',None)
        super().__init__(*args,**kwargs)
        if fields is not None: 
            # Drop any fields that are not specified in the `fields` argument.
            allowed = set(fields)
            existing = set(self.fields)
            for field_name in existing - allowed:
                self.fields.pop(field_name)

class OrganismSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Organism
        fields = ['id','taxa_id','clade','genus','species']
    
    def validate(self,data):
        if int(data['taxa_id']) <= 0:
            raise ValidationError('taxa id cannot be 0')
      
        return data
    
    def create(self,validated_data):
        try: 
            organism = Organism.objects.get_or_create(**validated_data)
            return organism[0]
        except Exception:
            
            raise ValidationError("organism object could not be fetched/created")
        
class PfamSerializer(serializers.ModelSerializer):
    class Meta: 
        model = Pfam
        fields = ['id','domain_id', 'domain_description']
    
    def create(self,validated_data):
        pfam = Pfam.objects.get_or_create(**validated_data)[0]
        return pfam
    
class DomainSerializer(serializers.ModelSerializer):
        
    pfam_id = PfamSerializer()
    
    class Meta:
        model = Domain 
        fields = ['id','pfam_id','description','start','stop']
    
    def validate(self,data):  
        if data['start'] > data['stop']:
            raise Exception("start greater than stop")
        if not data['start'] > 0: 
            raise Exception("start invalid")
        
        if not data['stop'] > 0: 
            raise Exception("Stop invalid")
        
        
        return data     
    
    def create(self,validated_data):
        try:
            pfam = Pfam.objects.get(domain_id=validated_data['pfam_id']['domain_id'])
            validated_data.pop('pfam_id')
            domain = Domain.objects.get_or_create(pfam_id=pfam,**validated_data)[0]
         
            return domain 
         
        except Pfam.DoesNotExist:
            raise Exception('Pfam does not exist')
         
class ProteinSerializer(serializers.ModelSerializer):
    taxonomy = OrganismSerializer(source='organism_id')
    
    domains = DomainSerializer(many=True)
    
    class Meta:
        model = Protein           
        fields = ['protein_id','sequence','taxonomy','length','domains']            
        read_only = ['id']
        
    def validate(self,data):
        if int(data['length']) < 0:
            raise ValueError("inappropriate length")
        
        return data 
    
    def get_domains(self,obj):
        domains = obj.domains.all()
        serialized_domains = DomainSerializer(domains, many=True).data
       
        return serialized_domains 
    
    def to_representation(self, instance):
        repr = super().to_representation(instance)
        # Remove the 'id' field from the 'taxonomy' object
        repr['taxonomy'].pop('id', None)

        # Remove the 'id' field from each 'pfam_id' object in the 'domains' list
        for domain in repr['domains']:
            domain.pop('id',None)
            domain['pfam_id'].pop('id', None)
        return repr
    def create(self, validated_data):
        """
        Create and return a new instance, given the validated data.
        """
        # print('is in protein serial')
        proteinData= validated_data  
        protein =  Protein.objects.create(protein_id=proteinData['protein_id'],organism_id=Organism.objects.get(taxa_id=proteinData['organism_id']['taxa_id']),sequence=proteinData['sequence'],length=proteinData['length'])
       
                
        return protein 

        
 
class OrganismProteinSerializer(DynamicFieldsModelSerializer):
                
    def to_representation(self,instance):
        repr= super().to_representation(instance)
        try: 
            
            if self.context['taxa_id'] != None : 
                repr['id'] = instance.id
                repr['protein_id'] = instance.protein_id
                return repr
              
        except KeyError:
          
            return Exception("inappropriate taxa_id") 

    class Meta:
        model = Protein    
        fields = ['protein_id','id']

class OrganismDomainSerializer(serializers.ModelSerializer):
  
    class Meta:
        model = Pfam
        fields = ['id','domain_id','domain_description']

class ProteinDomainSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProteinDomains
        exclude=['id']
        
