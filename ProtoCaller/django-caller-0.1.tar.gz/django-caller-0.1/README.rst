=====
Polls
=====

Caller is a Django / REST API that provides end points to a protein database. The API is also browsable, allowing for additional ease of use. 

Quick start
-----------

1. Add "caller" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...,
        "caller",
    ]

2. Include the polls URLconf in your project urls.py like this::

    path("caller/", include("caller.urls")),

 3. Run ``python manage.py migrate`` to create the caller models.

4. Run ``python manage.py loader`` to populate the database with the data in the /data directory of your main django root project 

5. Start the development server and visit http://127.0.0.1:8000
   
6. Links to all endpoints are provided in the home page. Visiting each link will take you to the endpoint view. Its specification/details is on the same page. 

7. Should you wish to run the tests - ``python manage.py test caller.tests``

